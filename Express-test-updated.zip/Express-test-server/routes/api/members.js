const express = require('express');
const router = express.Router();
const uuid = require('uuid');

const fs = require('fs');
const membersDir = '../../Members.json';
const membersFile = require(membersDir);



function membersFilterID(members, id) {
    return members.find(member => member.id === id.toString());
}

// Gets all members
router.get('/', (_req, res) =>  res.json(membersFile["members"]));

// Get single member

router.get('/:id', (req,res) => {
//     if(JSON.stringify(membersFile["members"]).includes(req.params.id.toString()))
    const found = membersFilterID(membersFile["members"],req.params.id);
    if (found) {
        res.json(found);
    }
    else {
        res.status(400).json({ msg: `No member with the id of ${req.params.id.toString()} found` })
    }


    // const found = membersFile["members"].filter(member => member.id.toString() === req.params.id.toString());
    // if(found.length > 0){
    //     res.json(found);
    // } else{
    //     res.status(400).json({ msg: `No member with the id of ${req.params.id.toString()} found`})
    // }

});

// Create Member
router.post('/', (req, res) => {
    const newMember = {
        id: uuid.v4(),
        name: req.body.name,
        email: req.body.email,
        status: 'active'
    }
    if (!newMember.name || !newMember.email) {
        res.status(400).json( { msg: 'Please include both a name and an email' } );
    }
    else {
        membersFile["members"].push(newMember);
        fs.writeFile('Members.json', JSON.stringify(membersFile,null,2), function writeJSON(err) {
            if (err) {
                return console.log(err);
            }
            console.log('writing to ' + membersDir);
        });
        res.json(membersFile);
    }
    //sends back a response of the body from post request
    // res.send(req.body);
});


// Update Member
router.put('/:id', (req,res) => {
    // const found = membersFile["members"].filter(member => member.id.toString() === req.params.id.toString());
    const found = membersFilterID(membersFile["members"], req.params.id);
    if (found)  {
        const updMember = req.body;
        found.name = updMember.name ? updMember.name : found.name;
        found.email = updMember.email ? updMember.email : found.email;
        fs.writeFile('Members.json', JSON.stringify(membersFile,null,2), function writeJSON(err) {
            if (err) {
                return console.log(err);
            }
            console.log('writing to ' + membersDir);

        });
        res.json({ msg: 'Member updated', member: found });
    } else {
        res.status(400).json({ msg: `No member with the id of ${req.params.id} found` });
    }

});

// Delete Member
router.delete('/:id', (req,res) => {
    let oldLength = membersFile["members"].length;
    membersFile["members"] = membersFile["members"].filter(member => member.id.toString() !== req.params.id.toString());
    if (membersFile["members"].length != oldLength) {
        fs.writeFile('Members.json', JSON.stringify(membersFile,null,2), function writeJSON(err) {
            if (err) {
                return console.log(err);
            }
            console.log('writing to ' + membersDir);
        });

        // console.log(membersFile);
        res.json({  msg: `member deleted`,
            members: membersFile["members"],

        });
    } else {
        res.status(400).json({ msg: `No member with the id of ${req.params.id} found` })
    }

});
module.exports = router;
