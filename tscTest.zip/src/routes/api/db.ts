import express, { Request, Response } from 'express';
import { verbose } from 'sqlite3';

const sqlite3 = verbose();
export const router = express.Router();

const db = new sqlite3.Database('./data.db',sqlite3.OPEN_READWRITE, (err) =>{
    if (err) {return console.error(err.message);}
});
router.use((req, res, next) => {
    const apiKey = req.get('API-Key')
    if (!apiKey || apiKey !== process.env.API_KEY) {
        res.status(401).json({ error: 'unauthorised' })
    } else {
        next()
    }
})
//gets data from db of all users http://localhost:5000/api/db/
router.get('/', (_req: Request, res: Response) => {
    db.all('select * from users', (error, results) => {
        if ( error ) {
            res.status(400).send('Error in database operation');
        } else {
            res.send(results);
        }
    });
});
//gets data from db of a single user http://localhost:5000/api/db/:id :id=id parameter
router.get('/:id', (req: Request, res: Response) => {
    db.all(`select * from users where id = ${parseInt(req.params.id)}`, (error, results) => {
        if ( error ) {
            res.status(400).send('Error in database operation');
        }
        results.forEach(results => {
            console.log(results);
        })
        res.send(results);
    });
});


//inserts a new user into the db
router.post('/', (req: Request, res: Response) => {
    const newUser = {
        first_name: req.body.first_name,
        last_name: req.body.last_name,
        email: req.body.email
    }
    if (!newUser.first_name || !newUser.last_name || !newUser.email) {
        res.status(400).json({ msg: 'Please include both a first name,last name and an email' });
    }
    else {
        const sql = 'INSERT INTO users(first_name,last_name,email) VALUES (?,?,?)';
        db.run(sql,
            [newUser.first_name,newUser.last_name,newUser.email], (err) =>  {
                if (err) {
                    res.    status(400).json({ msg: 'Please include both a name and an email/put a unique email' });
                    return console.error(err.message) }
                else { res.json({  msg: 'user added' });}
            })
    }
});
//deletes a user from the db
router.delete('/:id', (req: Request,res: Response) => {
    const sql = 'DELETE FROM users WHERE id=?';
    db.run(sql, [req.params.id], (err) => {
        if (err) {return console.error(err.message);}
        else {res.json({  msg: 'user deleted' });}
    })
});
