import express, { Express, Request, Response } from 'express';
import path from 'path';
import { logger } from './middleware/logger';
import { router as members } from './routes/api/members';
import { router as db } from './routes/api/db';
import swaggerUi from 'swagger-ui-express';
import swaggerDocument from './swagger.json';
const app: Express = express();
const port = process.env.PORT || 5000;

// Body Parser Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(logger);

// set static folder
app.use(express.static(path.join(__dirname,'public')));

// Members API Routes
app.use('/api/members', members);
app.use('/api/db', db);
// app.use('/api-docs', swaggerUi.serve, swaggerUi.setup(swaggerDocument));
const swaggerOptions = {
    swaggerOptions: {
        docExpansion: 'none', //tags are collapsed by default
        tagsSorter: 'alpha' //sort tags alphanumerically
    }
};

app.use('/api-docs',swaggerUi.serve,swaggerUi.setup(swaggerDocument,swaggerOptions));

app.get('/', (_req: Request, res: Response) => {
    res.send('Express + TypeScript Server');
});




app.listen(port, () => {
    console.log(`⚡️[server]: Server is running at http://localhost:${port}`);
});