import express, { Request, Response } from 'express';
import { v4 } from 'uuid';
import fs from 'fs';
import  membersFile  from  '../../Members.json';
import { body, validationResult } from 'express-validator';
// import { createUser, newEmail } from '../../middleware/validator';
import * as dotenv from 'dotenv';
dotenv.config();
const membersDir  = '../../Members.json';
const uuid = v4();
export const router = express.Router();

function membersFilterID(id : string) {
    return membersFile['members'].find(member => member.id === id);
}

router.use((req, res, next) => {
    const apiKey = req.get('API-Key')
    if (!apiKey || apiKey !== process.env.API_KEY) {
        res.status(401).json({ error: 'unauthorised' })
    } else {
        next()
    }
})


// Gets all members
router.get('/', (_req, res) => {
    res.status(200).json(membersFile['members'])
});

// Get single member

router.get('/:id', (req,res) => {
    const found = membersFilterID(req.params.id);
    if (found) {
        res.status(200).json(found);
    }
    else {
        res.status(400).json({ msg: `No member with the id of ${req.params.id} found` })
    }
});


// Create Member
router.post('/',
    body('name').isLength({ min: 3 }).withMessage('name must be at least 3 characters long'),
    body('email').isEmail().withMessage('not an email'),

    (req : Request, res : Response) => {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            return res.status(400).json({ errors: errors.array() });
        }
        const newMember = {
            id: uuid,
            name: req.body.name,
            email: req.body.email,
            status: 'active'
        }
        membersFile['members'].push(newMember);
        fs.writeFile('./src/Members.json', JSON.stringify(membersFile,null,2), function writeJSON(err) {
            if (err) {
                return console.log(err);
            }
            console.log('writing to ' + membersDir);
        });
        res.status(200).json(membersFile);
    });


// Update Member
router.put('/:id',
    body('name').isLength({ min: 3 }).withMessage('name must be at least 3 characters long'),
    body('email').isEmail().withMessage('not an email'),
    (req : Request, res : Response) => {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            return res.status(400).json({ errors: errors.array() });
        }
        const found = membersFilterID(req.params.id);
        if (found)  {
            const updMember = req.body;
            found.name = updMember.name ? updMember.name : found.name;
            found.email = updMember.email ? updMember.email : found.email;
            fs.writeFile('./src/Members.json', JSON.stringify(membersFile,null,2), function writeJSON(err) {
                if (err) {
                    return console.log(err);
                }
                console.log('writing to ' + membersDir);

            });
            res.status(200).json({ msg: 'Member updated', member: found });
        } else {
            res.status(400).json({ msg: `No member with the id of ${req.params.id} found` });
        }

    });

// Delete Member
router.delete('/:id', (req : Request,res : Response) => {
    const oldLength = membersFile['members'].length;
    membersFile['members'] = membersFile['members'].filter(member => member.id !== req.params.id);
    if (membersFile['members'].length != oldLength) {
        fs.writeFile('Members.json', JSON.stringify(membersFile,null,2), function writeJSON(err) {
            if (err) {
                return console.log(err);
            }
            console.log('writing to ' + membersDir);
        });

        // console.log(membersFile);
        res.status(200).json({  msg: 'member deleted',
            members: membersFile['members'],
        });
    } else {
        res.status(400).json({ msg: `No member with the id of ${req.params.id} found` })
    }

});
